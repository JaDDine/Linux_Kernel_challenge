#!/bin/bash

qemu-system-x86_64 \
    -m 128M \
    -kernel ./bzImage \
    -initrd ./initramfs.cpio.gz \
    -cpu kvm64,+smep,+smap \
    -append "console=ttyS0 nopti nokaslr nosmep nosmap quiet" \
    -monitor /dev/null \
    -nographic \
    -no-reboot
